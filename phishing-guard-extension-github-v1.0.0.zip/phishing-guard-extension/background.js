/* background.js — PhishGuard MV3 service worker.
 * Passive URL screening on navigation + interstitial for high-confidence
 * phishing, gated by the allowlist, the license tier and user strictness. */
"use strict";

importScripts("src/features.js", "src/model_data.js", "src/model.js",
              "src/allowlist_data.js", "src/engine.js", "src/license.js");

const WARN_BADGE = { color: "#D97B29", text: "!" };
const BLOCK_BADGE = { color: "#B5432F", text: "\u00D7" };

async function shouldSkip(url, tabId) {
  if (!/^https?:/i.test(url)) return true;
  const st = await PHG_LICENSE.getState();
  if (!st.enabled) return true;
  if (st.tier === "free") {
    const left = await PHG_LICENSE.quotaLeft();
    if (left <= 0) return true; // free quota exhausted; popup explains
    await PHG_LICENSE.bumpDailyCount();
  }
  return false;
}

async function inspectAndAct(tabId, url, frameId) {
  if (await shouldSkip(url, tabId)) return;
  const st = await PHG_LICENSE.getState();
  const v = PHG_ENGINE.verdict(url, { threshold: st.threshold });
  if (v.tier === "safe") {
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }
  if (v.tier === "suspicious") {
    chrome.action.setBadgeBackgroundColor({ tabId, color: WARN_BADGE.color });
    chrome.action.setBadgeText({ tabId, text: WARN_BADGE.text });
  }
  if (v.tier === "phishing") {
    chrome.action.setBadgeBackgroundColor({ tabId, color: BLOCK_BADGE.color });
    chrome.action.setBadgeText({ tabId, text: BLOCK_BADGE.text });
    const mode = st.strictness;
    if (mode === "block") {
      const target = chrome.runtime.getURL("interstitial.html") +
        "?u=" + encodeURIComponent(url) + "&p=" + encodeURIComponent(v.p.toFixed(3));
      chrome.tabs.update(tabId, { url: target });
    }
    // 'warn' mode: badge only; 'off' handled in shouldSkip
  }
}

chrome.webNavigation.onCommitted.addListener((details) => {
  if (details.frameId !== 0) return; // main frame only
  if (details.url.startsWith(chrome.runtime.getURL(""))) return;
  inspectAndAct(details.tabId, details.url, details.frameId).catch(console.error);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === "checkUrl") {
      const st = await PHG_LICENSE.getState();
      const v = PHG_ENGINE.verdict(msg.url, { threshold: st.threshold });
      sendResponse({ ok: true, verdict: serialize(v) });
    } else if (msg.type === "tabStatus") {
      const url = msg.url || "";
      const st = await PHG_LICENSE.getState();
      const v = PHG_ENGINE.verdict(url, { threshold: st.threshold });
      const quota = st.tier === "free" ? await PHG_LICENSE.quotaLeft() : null;
      sendResponse({ ok: true, verdict: serialize(v), state: st, quotaLeft: quota });
    } else if (msg.type === "continueAnyway") {
      // user acknowledged the interstitial: open the original URL this once
      chrome.tabs.update(sender.tab.id, { url: msg.url });
      sendResponse({ ok: true });
    } else if (msg.type === "markSafe") {
      const { phg_session_allow: set } = await chrome.storage.session
        .get({ phg_session_allow: [] });
      set.push(PHG_ENGINE.domainOf(PHG_ENGINE.hostOf(msg.url)));
      await chrome.storage.session.set({ phg_session_allow: set });
      sendResponse({ ok: true });
    } else if (msg.type === "getState") {
      sendResponse({ ok: true, state: await PHG_LICENSE.getState() });
    } else if (msg.type === "saveState") {
      await PHG_LICENSE.saveState(msg.patch);
      sendResponse({ ok: true });
    } else if (msg.type === "activate") {
      sendResponse(await PHG_LICENSE.activate(msg.key));
    } else if (msg.type === "deactivate") {
      await PHG_LICENSE.deactivate();
      sendResponse({ ok: true });
    }
  })().catch((e) => sendResponse({ ok: false, error: String(e) }));
  return true; // async response
});

function serialize(v) {
  // strip the heavy Float64Array before messaging the popup
  return { p: v.p, tier: v.tier, action: v.action, reason: v.reason,
           latencyMs: v.latencyMs || 0, host: v.host || "" };
}
