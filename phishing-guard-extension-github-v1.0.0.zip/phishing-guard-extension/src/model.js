/* model.js — compact binary forest loader + inference (PHWD-1 format).
 * Binary layout (little-endian):
 *   u32 magic 0x50485744 | u32 version | u32 nFeatures | u32 nTrees | u32 totalNodes
 *   f32 scalerMean[nFeatures] | f32 scalerScale[nFeatures]
 *   per tree: u32 nodeCount, then nodeCount nodes of
 *     i32 feature (-1 = leaf) | f32 threshold | i32 left | i32 right | f32 p1
 * p1 is the phishing-class probability contribution of the leaf. */
(function (global) {
  "use strict";

  function b64ToBytes(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }

  class PhishGuardModel {
    constructor(b64) {
      const bytes = b64ToBytes(b64);
      this.dv = new DataView(bytes.buffer);
      this.bytes = bytes;
      let off = 0;
      const magic = this.dv.getUint32(off, true); off += 4;
      if (magic !== 0x50485744) throw new Error("bad model magic " + magic);
      const version = this.dv.getUint32(off, true); off += 4;
      if (version !== 1) throw new Error("unsupported model version " + version);
      this.nFeatures = this.dv.getUint32(off, true); off += 4;
      this.nTrees = this.dv.getUint32(off, true); off += 4;
      this.totalNodes = this.dv.getUint32(off, true); off += 4;

      this.mean = new Float32Array(this.nFeatures);
      this.scale = new Float32Array(this.nFeatures);
      for (let i = 0; i < this.nFeatures; i++) { this.mean[i] = this.dv.getFloat32(off, true); off += 4; }
      for (let i = 0; i < this.nFeatures; i++) { this.scale[i] = this.dv.getFloat32(off, true); off += 4; }

      this.trees = new Array(this.nTrees);
      for (let t = 0; t < this.nTrees; t++) {
        const count = this.dv.getUint32(off, true); off += 4;
        // structure-of-arrays layout, matching the Python exporter:
        // [features i32 x count][thresholds f32 x count][left i32 x count]
        // [right i32 x count][p1 f32 x count]
        const feats = new Int32Array(count);
        const thr = new Float32Array(count);
        const left = new Int32Array(count);
        const right = new Int32Array(count);
        const p1 = new Float32Array(count);
        for (let n = 0; n < count; n++) feats[n] = this.dv.getInt32(off + 4 * n, true);
        off += 4 * count;
        for (let n = 0; n < count; n++) thr[n] = this.dv.getFloat32(off + 4 * n, true);
        off += 4 * count;
        for (let n = 0; n < count; n++) left[n] = this.dv.getInt32(off + 4 * n, true);
        off += 4 * count;
        for (let n = 0; n < count; n++) right[n] = this.dv.getInt32(off + 4 * n, true);
        off += 4 * count;
        for (let n = 0; n < count; n++) p1[n] = this.dv.getFloat32(off + 4 * n, true);
        off += 4 * count;
        this.trees[t] = { feats, thr, left, right, p1 };
      }
    }

    /* rawFeatures: Float64Array(54) -> scaled vector (Float32Array) */
    scaleVector(raw) {
      const out = new Float32Array(this.nFeatures);
      for (let i = 0; i < this.nFeatures; i++) {
        out[i] = (raw[i] - this.mean[i]) / this.scale[i];
      }
      return out;
    }

    /* x: Float32Array(scaled) -> phishing probability in [0,1] */
    predictProba(x) {
      let sum = 0.0;
      for (let t = 0; t < this.trees.length; t++) {
        const tr = this.trees[t];
        let node = 0;
        while (tr.feats[node] >= 0) { // sklearn marks leaves with TREE_UNDEFINED = -2
          const v = x[tr.feats[node]];
          node = v <= tr.thr[node] ? tr.left[node] : tr.right[node];
        }
        sum += tr.p1[node];
      }
      return sum / this.trees.length;
    }
  }

  global.PHG_MODEL = { PhishGuardModel, b64ToBytes };
})(typeof self !== "undefined" ? self : globalThis);
