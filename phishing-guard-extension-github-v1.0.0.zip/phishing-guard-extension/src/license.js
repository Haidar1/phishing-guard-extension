/* license.js — freemium gating with an OFFLINE license stub.
 *
 * !! PRODUCTION NOTE !!
 * verifyLicense() below validates key FORMAT only (demo-grade). Before
 * charging real money, replace it with a call to your license server
 * (sample server in PACKAGING_AND_PAYMENTS.md) and cache the signed
 * response in chrome.storage. Never trust client-side-only checks for
 * anything beyond casual enforcement.
 */
(function (global) {
  "use strict";

  const FREE_DAILY_LIMIT = 200; // passive checks per day on the free tier

  const DEFAULTS = {
    tier: "free",
    licenseKey: "",
    strictness: "block",   // 'off' | 'warn' | 'block'
    threshold: 0.9,        // blocking threshold (Pro can tune 0.5-0.99)
    enabled: true,
  };

  async function getState() {
    const st = await chrome.storage.sync.get(DEFAULTS);
    return Object.assign({}, DEFAULTS, st);
  }

  async function saveState(patch) {
    await chrome.storage.sync.set(patch);
  }

  function keyChecksum(key) {
    // PHG-PRO-XXXX-XXXX-XXXX ; last group carries a mod-36 checksum of the rest
    const m = /^PHG-PRO-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9]{4})$/.exec(key || "");
    if (!m) return false;
    const body = (m[1] + m[2]).split("").reduce((a, c) => a + c.charCodeAt(0), 0);
    const chk = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(body % 36 + 36) % 36];
    return m[3][3] === chk;
  }

  async function activate(key) {
    key = (key || "").trim().toUpperCase();
    const ok = keyChecksum(key); // TODO(server): replace with POST /v1/activate
    if (ok) {
      await saveState({ tier: "pro", licenseKey: key });
      return { ok: true, tier: "pro" };
    }
    return { ok: false, error: "Invalid license key" };
  }

  async function deactivate() {
    await saveState({ tier: "free", licenseKey: "" });
  }

  async function bumpDailyCount() {
    const today = new Date().toISOString().slice(0, 10);
    const { phg_count_date: d, phg_count_n: n } =
      await chrome.storage.local.get({ phg_count_date: "", phg_count_n: 0 });
    if (d !== today) {
      await chrome.storage.local.set({ phg_count_date: today, phg_count_n: 1 });
      return 1;
    }
    await chrome.storage.local.set({ phg_count_n: n + 1 });
    return n + 1;
  }

  async function quotaLeft() {
    const today = new Date().toISOString().slice(0, 10);
    const { phg_count_date: d, phg_count_n: n } =
      await chrome.storage.local.get({ phg_count_date: "", phg_count_n: 0 });
    if (d !== today) return FREE_DAILY_LIMIT;
    return Math.max(0, FREE_DAILY_LIMIT - n);
  }

  global.PHG_LICENSE = {
    DEFAULTS, getState, saveState, activate, deactivate,
    bumpDailyCount, quotaLeft, FREE_DAILY_LIMIT,
  };
})(typeof self !== "undefined" ? self : globalThis);
