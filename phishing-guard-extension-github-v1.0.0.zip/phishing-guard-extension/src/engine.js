/* engine.js — ties feature extraction, the forest, the allowlist and the
 * license tier into one verdict API used by both the service worker and
 * the popup. */
(function (global) {
  "use strict";

  const { FEATURE_NAMES, extractFeatures } = global.PHG_FEATURES;

  let model = null;
  let allowlist = null;      // Set of top-10k umbrella domains
  // Brand + mainstream-infrastructure domains that must never be blocked.
  // Deliberately EXCLUDES abusable free hosts (vercel.app, github.io, ...)
  // because live phishing campaigns ride on them.
  let brandAllow = new Set([
    "google.com", "youtube.com", "gmail.com", "microsoft.com", "outlook.com",
    "office.com", "live.com", "msn.com", "bing.com", "apple.com", "icloud.com",
    "amazon.com", "paypal.com", "netflix.com", "facebook.com", "instagram.com",
    "whatsapp.com", "twitter.com", "x.com", "linkedin.com", "tiktok.com",
    "ebay.com", "yahoo.com", "openai.com", "anthropic.com", "wikipedia.org",
    "mozilla.org", "adobe.com", "oracle.com", "ibm.com", "cisco.com",
    "dell.com", "hp.com", "samsung.com", "nvidia.com", "intel.com",
    "github.com", "gitlab.com", "stackoverflow.com", "cloudflare.com",
    "jsdelivr.net", "googleapis.com", "gstatic.com", "amazonaws.com",
    "akamai.com", "fastly.net", "un.org", "who.int",
  ]);

  function initModel() {
    if (model) return model;
    model = new global.PHG_MODEL.PhishGuardModel(global.PHG_MODEL_DATA);
    allowlist = new Set(global.PHG_ALLOWLIST || []);
    return model;
  }

  function hostOf(url) {
    try {
      return new URL(url).hostname.toLowerCase();
    } catch (e) {
      return "";
    }
  }

  function domainOf(host) {
    const parts = host.split(".").filter(Boolean);
    if (parts.length >= 2) return parts.slice(-2).join(".");
    return host;
  }

  /* verdict(url, {threshold}) -> {p, tier, action, reason}
   * tier: 'safe' | 'suspicious' | 'phishing'
   * action: 'allow' | 'warn' | 'block' (block = show interstitial) */
  function verdict(url, opts) {
    initModel();
    const threshold = (opts && opts.threshold) || 0.9;
    const host = hostOf(url);
    const dom = domainOf(host);

    if (!/^https?:/i.test(url)) {
      return { p: 0, tier: "safe", action: "allow", reason: "non-http scheme" };
    }
    if (allowlist && (allowlist.has(host) || allowlist.has(dom))) {
      return { p: 0, tier: "safe", action: "allow", reason: "top-domain allowlist" };
    }
    if (brandAllow.has(host) || brandAllow.has(dom)) {
      return { p: 0, tier: "safe", action: "allow", reason: "known brand domain" };
    }

    const t0 = Date.now();
    const raw = extractFeatures(url);
    const x = model.scaleVector(raw);
    const p = model.predictProba(x);
    const latency = Date.now() - t0;

    let tier = "safe", action = "allow", reason = "model probability below threshold";
    if (p >= threshold) { tier = "phishing"; action = "block"; reason = "model probability above blocking threshold"; }
    else if (p >= 0.5) { tier = "suspicious"; action = "warn"; reason = "model probability in suspicion band"; }
    return { p: p, tier: tier, action: action, reason: reason, latencyMs: latency,
             features: raw, host: host, domain: dom };
  }

  global.PHG_ENGINE = { initModel, verdict, hostOf, domainOf, FEATURE_NAMES };
})(typeof self !== "undefined" ? self : globalThis);
