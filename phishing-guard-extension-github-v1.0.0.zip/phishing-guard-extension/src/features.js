/* features.js — 54-lexical-feature extractor (browser port of features.py).
 * Must stay byte-compatible with the Python training pipeline:
 * scripts/phish/features.py (feature order = FEATURE_NAMES below). */
(function (global) {
  "use strict";

  const FEATURE_NAMES = [
    "url_length", "hostname_length", "domain_length", "path_length", "query_length",
    "num_dots", "num_slash", "num_hyphens", "num_underscore", "num_at",
    "num_question", "num_ampersand", "num_equal", "num_percent", "num_plus",
    "num_hash", "num_semicolon", "num_comma", "num_numeric", "num_uppercase",
    "num_special_chars", "num_suspicious_words", "num_subdomains", "path_depth",
    "num_tld", "max_consecutive_digits", "num_consonants",
    "digit_to_length_ratio", "letters_to_length_ratio", "hyphens_to_length_ratio",
    "dots_to_length_ratio", "special_to_length_ratio", "uppercase_to_length_ratio",
    "suspicious_to_length_ratio", "consonant_to_length_ratio",
    "has_ip_address", "has_https", "has_www", "has_at", "has_port", "has_query",
    "has_fragment", "has_shortening_service", "has_double_slash_redirect",
    "has_punycode", "has_hex_encoding", "has_popular_tld", "has_suspicious_tld",
    "has_suspicious_words", "is_brand_typosquat", "has_suspicious_port",
    "domain_entropy", "hostname_entropy", "min_brand_edit_distance",
  ];

  const SUSPICIOUS_WORDS = [
    "login", "signin", "signon", "verify", "account", "secure", "security",
    "update", "confirm", "password", "credential", "auth", "webscr",
    "paypal", "ebay", "amazon", "microsoft", "office", "outlook", "apple",
    "icloud", "netflix", "instagram", "linkedin", "yahoo", "bank",
  ];
  const BRANDS = [
    "google", "facebook", "paypal", "amazon", "microsoft", "apple",
    "netflix", "instagram", "twitter", "linkedin", "ebay", "yahoo",
  ];
  const POPULAR_TLDS = new Set(["com", "org", "net", "edu", "gov"]);
  const SUSPICIOUS_TLDS = new Set([
    "tk", "ml", "ga", "cf", "gq", "xyz", "top", "club", "online", "site",
    "buzz", "info", "biz", "click", "link", "work", "live", "rest", "icu",
    "cyou",
  ]);
  const SHORTENERS = [
    "bit.ly", "goo.gl", "t.co", "tinyurl.com", "is.gd", "ow.ly", "buff.ly",
    "adf.ly", "bit.do", "cutt.ly", "rebrand.ly", "tiny.cc", "shorturl.at",
  ];
  const BAD_PORTS = new Set(["8080", "8443", "80", "8000", "8888"]);
  const IP_RE = /^(\d{1,3}\.){3}\d{1,3}$/;
  const HEX_RE = /%(?:[0-9a-fA-F]{2})|0x[0-9a-fA-F]+/;
  const TOKEN_RE = /[a-z0-9]+/g;

  function shannonEntropy(s) {
    if (!s) return 0.0;
    const counts = new Map();
    for (const ch of s) counts.set(ch, (counts.get(ch) || 0) + 1);
    const n = s.length;
    let h = 0.0;
    for (const c of counts.values()) {
      const p = c / n;
      h -= p * Math.log2(p);
    }
    return h;
  }

  function levenshtein(a, b, cap) {
    cap = cap || 99;
    const la = a.length, lb = b.length;
    if (Math.abs(la - lb) > cap) return cap + 1;
    if (la === 0) return lb;
    if (lb === 0) return la;
    let prev = new Array(lb + 1);
    for (let j = 0; j <= lb; j++) prev[j] = j;
    for (let i = 1; i <= la; i++) {
      const cur = [i];
      const ca = a.charCodeAt(i - 1);
      let best = i;
      for (let j = 1; j <= lb; j++) {
        const cost = ca === b.charCodeAt(j - 1) ? 0 : 1;
        let v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost);
        cur[j] = v;
        if (v < best) best = v;
      }
      if (best > cap) return cap + 1;
      prev = cur;
    }
    return prev[lb];
  }

  function splitUrl(u) {
    const base = u.replace(/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\//, "");
    const m = base.match(/^[^/?#]+/);
    const netloc = m ? m[0] : "";
    const m2 = base.match(/\/([^?#]*)/);
    const path = m2 ? "/" + m2[1] : "";
    const m3 = base.match(/\?([^#]*)/);
    const query = m3 ? m3[1] : "";
    let host = netloc, port = "";
    const ci = netloc.lastIndexOf(":");
    if (ci !== -1) {
      const h = netloc.slice(0, ci), p = netloc.slice(ci + 1);
      if (h && /^\d+$/.test(p)) { host = h; port = p; }
    }
    return { host: host.toLowerCase(), path: path, query: query, port: port };
  }

  function domainLabel(host) {
    const parts = host.split(".").filter(Boolean);
    if (parts.length >= 2) return parts[parts.length - 2];
    return parts[0] || "";
  }

  function tldLabel(host) {
    const parts = host.split(".").filter(Boolean);
    return parts.length >= 2 ? parts[parts.length - 1] : "";
  }

  function brandMinDist(domain) {
    const toks = String(domain).toLowerCase().match(TOKEN_RE) || [];
    let best = 99;
    for (const t of toks) {
      if (t.length > 32) continue;
      for (const b of BRANDS) {
        const d = levenshtein(t, b, 4);
        if (d < best) { best = d; if (best === 0) return 0; }
      }
    }
    return best;
  }

  /* Returns the 54 features as a plain Float64Array in FEATURE_NAMES order. */
  function extractFeatures(url) {
    const u = String(url).trim();
    const lower = u.toLowerCase();
    const n = u.length;
    const sp = splitUrl(u);
    const host = sp.host, path = sp.path, query = sp.query, port = sp.port;
    const domain = domainLabel(host);
    const tld = tldLabel(host);
    const subCnt = host ? Math.max(host.split(".").length - 2, 0) : 0;

    let letters = 0, digits = 0, specials = 0, uppers = 0, vowels = 0;
    for (const ch of u) {
      if ((ch >= "a" && ch <= "z") || (ch >= "A" && ch <= "Z")) letters++;
      else if (ch >= "0" && ch <= "9") digits++;
      else specials++;
      if (ch >= "A" && ch <= "Z") uppers++;
      if ("aeiouAEIOU".includes(ch)) vowels++;
    }
    const consonants = Math.max(letters - vowels, 0);
    let matched = 0;
    for (const w of SUSPICIOUS_WORDS) if (lower.includes(w)) matched++;

    const digitRuns = u.match(/\d+/g) || [];
    let maxRun = 0;
    for (const r of digitRuns) if (r.length > maxRun) maxRun = r.length;

    const uniqSpecial = new Set();
    for (const ch of u) if (!/[A-Za-z0-9]/.test(ch)) uniqSpecial.add(ch);

    const count = (s, ch) => {
      let c = 0;
      for (const x of s) if (x === ch) c++;
      return c;
    };
    const nz = n || 1; // python guards divide by zero; same via fillna(0)
    const f = {};
    f.url_length = n;
    f.hostname_length = host.length;
    f.domain_length = domain.length;
    f.path_length = path.length;
    f.query_length = query.length;
    f.num_dots = count(u, ".");
    f.num_slash = count(u, "/");
    f.num_hyphens = count(u, "-");
    f.num_underscore = count(u, "_");
    f.num_at = count(u, "@");
    f.num_question = count(u, "?");
    f.num_ampersand = count(u, "&");
    f.num_equal = count(u, "=");
    f.num_percent = count(u, "%");
    f.num_plus = count(u, "+");
    f.num_hash = count(u, "#");
    f.num_semicolon = count(u, ";");
    f.num_comma = count(u, ",");
    f.num_numeric = digits;
    f.num_uppercase = uppers;
    f.num_special_chars = specials;
    f.num_suspicious_words = matched;
    f.num_subdomains = subCnt;
    f.path_depth = path.split("/").filter(Boolean).length;
    f.num_tld = tld ? 1 : 0;
    f.max_consecutive_digits = maxRun;
    f.num_consonants = consonants;
    f.digit_to_length_ratio = n ? digits / n : 0;
    f.letters_to_length_ratio = n ? letters / n : 0;
    f.hyphens_to_length_ratio = n ? count(u, "-") / n : 0;
    f.dots_to_length_ratio = n ? count(u, ".") / n : 0;
    f.special_to_length_ratio = n ? uniqSpecial.size / n : 0;
    f.uppercase_to_length_ratio = n ? uppers / n : 0;
    f.suspicious_to_length_ratio = n ? matched / n : 0;
    f.consonant_to_length_ratio = n ? consonants / n : 0;
    f.has_ip_address = host && IP_RE.test(host) ? 1 : 0;
    f.has_https = lower.startsWith("https://") ? 1 : 0;
    f.has_www = host.startsWith("www.") ? 1 : 0;
    f.has_at = u.includes("@") ? 1 : 0;
    f.has_port = port !== "" ? 1 : 0;
    f.has_query = u.includes("?") ? 1 : 0;
    f.has_fragment = u.includes("#") ? 1 : 0;
    f.has_shortening_service = SHORTENERS.some((s) => lower.includes(s)) ? 1 : 0;
    f.has_double_slash_redirect = u.indexOf("//", 8) !== -1 ? 1 : 0;
    f.has_punycode = lower.includes("xn--") ? 1 : 0;
    f.has_hex_encoding = HEX_RE.test(u) ? 1 : 0;
    f.has_popular_tld = POPULAR_TLDS.has(tld) ? 1 : 0;
    f.has_suspicious_tld = SUSPICIOUS_TLDS.has(tld) ? 1 : 0;
    f.has_suspicious_words = matched > 0 ? 1 : 0;
    const dist = brandMinDist(domain);
    f.is_brand_typosquat = dist <= 2 ? 1 : 0;
    f.has_suspicious_port = BAD_PORTS.has(port) ? 1 : 0;
    f.domain_entropy = shannonEntropy(domain);
    f.hostname_entropy = shannonEntropy(host);
    f.min_brand_edit_distance = dist;

    const out = new Float64Array(FEATURE_NAMES.length);
    for (let i = 0; i < FEATURE_NAMES.length; i++) out[i] = f[FEATURE_NAMES[i]];
    return out;
  }

  global.PHG_FEATURES = { FEATURE_NAMES, extractFeatures };
})(typeof self !== "undefined" ? self : globalThis);
