# PhishGuard — On-Device Phishing URL Detector

Real-time phishing URL screening powered by a 54-feature random forest that runs **entirely in your browser**. No URL ever leaves your device — there is no server, no telemetry, and no history upload.

Built on the Extreme Random Forest (ERF) model described in the accompanying research (99.8%+ detection accuracy, validated on out-of-distribution benign traffic).

## Features

- **On-device inference** — a compact 60-tree ERF (~1.1 MB) runs inside the browser service worker
- **54 URL features** — lexical, structural, and host-based signals extracted in real time via `webNavigation`
- **Two-stage allowlist** — top-10k Tranco/Umbrella domains + brand list to eliminate false positives on popular sites
- **Warning interstitial** — full-page warning when a URL scores above the decision threshold, with "go back" / "proceed anyway" options
- **Freemium licensing** — 200 checks/day free; `PHG-PRO` license keys unlock unlimited checks
- **Badge feedback** — toolbar icon reflects the risk verdict for the active tab

## Install (Developer Mode)

1. Download the latest `phishing-guard-extension-v1.0.0.zip` from the [Releases](../../releases) page (or clone this repo).
2. Unzip it to a folder on your computer.
3. Open Chrome and go to `chrome://extensions`.
4. Toggle **Developer mode** ON (top-right corner).
5. Click **Load unpacked** and select the unzipped folder (the one containing `manifest.json`).
6. Pin PhishGuard to your toolbar and start browsing.

## Repository Structure

```
phishing-guard-extension/
├── manifest.json          # MV3 extension manifest (v1.0.0)
├── background.js          # Service worker: navigation listener + scoring pipeline
├── popup.html / popup.js  # Toolbar popup UI (status, counters, license entry)
├── interstitial.html / .js# Full-page warning screen for flagged URLs
├── model_meta.json        # Model metadata (threshold, feature spec, version)
├── icons/                 # Toolbar + store icons (16/32/48/128 px)
└── src/
    ├── engine.js          # Orchestrates feature extraction → model → verdict
    ├── features.js        # 54-feature JS port (cross-validated vs Python)
    ├── model.js           # Compact random-forest inference
    ├── model_data.js      # Serialized forest weights
    ├── allowlist.json / allowlist_data.js  # Two-stage benign allowlist
    └── license.js         # Freemium license validation
```

## Privacy

- URLs are scored locally in the service worker; nothing is transmitted.
- No analytics, no remote logging, no account required.
- Permissions used: `webNavigation` (observe navigations), `storage` (settings/license), `tabs` (badge updates).

## License

© 2025 Aliyu Sulaiman. All rights reserved. Free tier: 200 URL checks/day. Contact the author for Pro license keys.
