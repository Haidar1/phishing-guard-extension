# PhishGuard — Packaging, Publishing & Payments Guide

This guide answers three questions: **how to test it**, **how to get it into each browser store**, and **how to collect money** once it is live. Everything referenced here exists in this folder — the extension is fully built, cross-validated against the Python model (15/15 verdict match), and zipped and ready for store upload (`../phishing-guard-extension-v1.0.0.zip`).

---

## 1. Test it on your own machine first (free, 5 minutes)

Chrome, Edge, Brave and Opera all load unpacked extensions the same way:

1. Unzip `phishing-guard-extension-v1.0.0.zip` to a folder (or use this folder directly).
2. Open `chrome://extensions` (or `edge://extensions`).
3. Turn on **Developer mode** (toggle, top-right).
4. Click **Load unpacked** and select the folder that contains `manifest.json`.
5. Pin the PhishGuard icon, then browse. Visits to a top-10,000 domain or a known brand are passed instantly by the allowlist; anything else is scored on-device by the 54-feature forest.
6. Try the popup's URL checker with a live sample such as `http://paypa1-verify.com/signin/update` (should read PHISHING, p ≈ 0.99) and `https://www.wikipedia.org` (benign). The interstitial warning page appears when you navigate to something the model scores ≥ 0.9 with strictness set to *Block*.

Firefox also works in developer mode: `about:debugging#/runtime/this-firefox` → **Load Temporary Add-on** → pick `manifest.json`.

---

## 2. Publishing to the browser stores

### Chrome Web Store — the $5 you asked about

The **US $5.00 registration fee is a one-time, per-account charge** — not per extension and not per year. You pay it once and can publish unlimited extensions under that account forever.

1. Create/choose a Google account, then go to the [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole) and pay the $5 one-time fee (credit/debit card via Google payments).
2. Upload the **zip file as-is** (manifest at the zip root — already correct).
3. Fill in the store listing: description, category (Productivity → Security), screenshots (1280×800), and the icons already included.
4. **Permission justifications** (reviewers ask for these; answer exactly like this):
   - `webNavigation` — "Required to screen the URL of each page the user navigates to, on-device, to warn against phishing."
   - `tabs` — "Used to read the current tab's URL for the popup verdict and to display our interstitial warning page."
   - `storage` — "Stores user settings (strictness, license state) and a daily counter locally."
5. **Privacy tab**: declare single purpose (phishing URL screening), state that you do **not** collect, transmit or sell user data (true — everything is on-device; no analytics, no remote calls), and provide a privacy policy URL. A free privacy-policy page on GitHub Pages or Notion is acceptable to reviewers.
6. Submit for review. On-device extensions with no remote code and no host permissions usually review in **1–3 business days**; expect longer if Google has questions. There is no annual fee after that.

> One compliance note: `web_accessible_resources` currently exposes `interstitial.html` to all URLs, which is fine, but keep **no remote code** — all model and logic files are bundled (they are), because Chrome MV3 forbids loading executable code from the network.

### Firefox Add-ons (AMO) — free

1. Sign up at [addons.mozilla.org/developers](https://addons.mozilla.org/developers/) — **no fee**.
2. Submit the same zip (or a slightly adapted copy). AMO runs an automated + human review; typical turnaround a few days.
3. Firefox MV3 quirk: `background.service_worker` should be aliased as event pages. If the automated checker complains, add to `manifest.json`: `"background": { "service_worker": "background.js", "scripts": ["background.js"] }` — the importScripts chain already works in both runtimes.

### Microsoft Edge Add-ons — free

1. Register at the [Edge Partner Center](https://partner.microsoft.com/dashboard/microsoftedge) — **no fee**.
2. Upload the same zip; Edge accepts Chrome MV3 extensions unchanged. Review is usually 1–7 days.

**Strategy worth knowing:** Chrome is where you pay; Firefox and Edge cost nothing and reuse the identical package, so publish on all three.

---

## 3. Getting paid — the monetization path

The extension ships with a **freemium license system already wired in** (`src/license.js`):

- **Free tier**: 200 URL checks per day, fixed 0.9 blocking threshold.
- **Pro tier**: unlimited checks + tunable threshold (0.5–0.99) + strictness control. Activated by a `PHG-PRO-XXXX-XXXX-XXXX` license key entered in the popup.

Important: the **Chrome Web Store no longer processes payments for extensions**, so the standard indie pattern is *sell keys on your own site, validate in the extension*:

1. **Collect payment** with a merchant of record so you don't handle VAT yourself: [ExtensionPay](https://extensionpay.com) (built exactly for this, free up to a point), **Paddle**, **Lemon Squeezy**, or **Gumroad**. Price example: $3/month or $20/year for Pro.
2. **After payment, issue a key.** Your license server generates keys in the exact format the extension checks (`PHG-PRO-XXXX-XXXX-XXXX` with the mod-36 checksum in the last group — generator below).
3. **User pastes the key in the popup** → `PHG_LICENSE.activate()` validates it → Pro features unlock.
4. **Before you charge real money**, replace the format-only check in `license.js` (line 43, marked `TODO(server)`) with a server call, because client-side-only validation is trivially bypassed:

```js
// license.js — production replacement for activate()
async function activate(key) {
  try {
    const r = await fetch("https://your-server.example/api/activate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, device: chrome.runtime.id }),
    });
    const j = await r.json();
    if (j.ok) { await saveState({ tier: "pro", licenseKey: key }); return { ok: true, tier: "pro" }; }
    return { ok: false, error: j.error || "Invalid or already-used key" };
  } catch (e) { return { ok: false, error: "Network error — try again" }; }
}
```

### Minimal license server (Python/Flask, ~40 lines)

```python
import random, re, string
from flask import Flask, request, jsonify

ALPHABET = string.ascii_uppercase + string.digits
CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
app = Flask(__name__)
KEYS = {"issued": set()}          # demo store; use SQLite/Postgres in production

def checksum(body: str) -> str:
    """Mirrors license.js: sum of char codes of the FIRST TWO groups, mod 36."""
    return CHARS[sum(ord(c) for c in body) % 36]

def new_key() -> str:
    g = lambda: "".join(random.choices(ALPHABET, k=4))
    while True:
        g1, g2 = g(), g()
        key = f"PHG-PRO-{g1}-{g2}-{g()[:3]}{checksum(g1 + g2)}"
        if key not in KEYS["issued"]:
            return key

@app.post("/api/issue")            # call this from your payment webhook
def issue():
    k = new_key(); KEYS["issued"].add(k)
    return jsonify(key=k)

@app.post("/api/activate")
def activate():
    key = (request.json or {}).get("key", "").strip().upper()
    m = re.fullmatch(r"PHG-PRO-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9]{4})", key)
    if not m:
        return jsonify(ok=False, error="Invalid format")
    if m.group(3)[3] != checksum(m.group(1) + m.group(2)):
        return jsonify(ok=False, error="Invalid key")
    if key not in KEYS["issued"]:
        return jsonify(ok=False, error="Key not recognised")
    return jsonify(ok=True)
```

For a solo developer the simplest credible stack is: **Gumroad or Paddle for payment → webhook issues the key → key stored in a small SQLite table → extension validates on activation and caches the signed response in `chrome.storage`**. ExtensionPay shortcuts all three if you'd rather not run a server at all.

---

## 4. Pre-submission checklist

- [x] `manifest.json` valid MV3, name/version/description/author set
- [x] Icons 16/32/48/128 included
- [x] All model + allowlist assets bundled; **zero remote code**
- [x] Engine cross-validated against the Python model (15/15, worst |Δp| = 0.000005)
- [x] Interstitial + badge + popup flows working; free-tier quota (200/day) active
- [x] Store zip built: `../phishing-guard-extension-v1.0.0.zip` (634 KB)
- [ ] Your privacy policy URL
- [ ] Screenshots 1280×800 (popup + interstitial make good shots)
- [ ] Payment provider account + license endpoint wired into `license.js`
- [ ] After review passes: monitor the dashboard for error reports; bump `version` in `manifest.json` for every update you upload

## 5. Where the numbers come from

The bundled model is the deployment-compact variant of the paper's Enhanced Random Forest: 60 trees, depth 12, trained on PhiUSIIL (235,795 URLs) + 25,000 conventions-matched benign domains, 54 lexical features. Its documented external performance: **phishing recall 95%** on live OpenPhish URLs with **24.7% FPR at threshold 0.5**, reduced to **1.5% FPR at the 0.9 threshold the extension actually uses** — plus the two-stage allowlist (top-10k domains + brand list) that screens the most-visited web properties before the model ever runs. Full methodology and mitigation study are in the republished paper.
