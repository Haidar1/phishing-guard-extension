"use strict";
const params = new URLSearchParams(location.search);
const target = params.get("u") || "";
const prob = params.get("p") || "";
document.getElementById("u").textContent = target;
document.getElementById("m").textContent =
  "Model phishing probability: " + (prob ? (parseFloat(prob) * 100).toFixed(1) + "%" : "n/a");

document.getElementById("back").addEventListener("click", () => history.length > 1 ? history.back() : (location.href = "https://www.google.com"));
document.getElementById("report").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "markSafe", url: target }, () => {
    document.getElementById("m").textContent = "Marked safe for this session. Re-open the site to continue.";
  });
});
document.getElementById("continue").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "continueAnyway", url: target }, () => { window.close(); });
});
