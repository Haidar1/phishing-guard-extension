"use strict";

const $ = (id) => document.getElementById(id);
const statusEl = $("status");

function renderStatus(v) {
  statusEl.className = "status " + v.tier;
  const pct = (v.p * 100).toFixed(1);
  if (v.tier === "phishing") {
    statusEl.textContent = `Likely phishing (${pct}%). Host: ${v.host || "n/a"}. ` +
      "Close this page or reach the service through its official site.";
  } else if (v.tier === "suspicious") {
    statusEl.textContent = `Suspicious URL (${pct}%). Think twice before entering any ` +
      "credentials on this site.";
  } else {
    statusEl.textContent = v.reason === "top-domain allowlist" || v.reason === "known brand domain"
      ? "This domain is on the trusted allowlist."
      : `No phishing signals detected (${pct}%).`;
  }
}

async function refresh() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage({ type: "tabStatus", url: tab && tab.url }, (res) => {
    if (!res || !res.ok) { statusEl.textContent = "Unavailable on this page."; return; }
    renderStatus(res.verdict);
    $("tier").textContent = res.state.tier;
    $("strict").value = res.state.strictness;
    $("thr").value = res.state.threshold;
    $("thrVal").textContent = Number(res.state.threshold).toFixed(2);
    $("enabled").checked = res.state.enabled;
    const pro = res.state.tier === "pro";
    $("thrRow").style.opacity = pro ? 1 : 0.45;
    $("thrRow").style.pointerEvents = pro ? "auto" : "none";
    $("deactivateBtn").classList.toggle("hidden", !pro);
    $("activateBtn").classList.toggle("hidden", pro);
    $("quota").textContent = pro ? "Pro: unlimited screening" :
      `Free plan: ${res.quotaLeft} passive checks left today`;
  });
}

$("checkBtn").addEventListener("click", () => {
  let u = $("manual").value.trim();
  if (!u) return;
  if (!/^https?:\/\//i.test(u)) u = "http://" + u;
  chrome.runtime.sendMessage({ type: "checkUrl", url: u }, (res) => {
    if (res && res.ok) renderStatus(res.verdict);
  });
});

$("strict").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "saveState", patch: { strictness: e.target.value } }, refresh));
$("thr").addEventListener("input", (e) => {
  $("thrVal").textContent = Number(e.target.value).toFixed(2);
  chrome.runtime.sendMessage({ type: "saveState", patch: { threshold: parseFloat(e.target.value) } });
});
$("enabled").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "saveState", patch: { enabled: e.target.checked } }, refresh));

$("activateBtn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "activate", key: $("key").value }, (res) => {
    const m = $("msg");
    if (res && res.ok) { m.className = "msg ok"; m.textContent = "Pro activated."; refresh(); }
    else { m.className = "msg"; m.textContent = (res && res.error) || "Activation failed."; }
  });
});
$("deactivateBtn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "deactivate" }, () => { $("key").value = ""; refresh(); });
});

refresh();
